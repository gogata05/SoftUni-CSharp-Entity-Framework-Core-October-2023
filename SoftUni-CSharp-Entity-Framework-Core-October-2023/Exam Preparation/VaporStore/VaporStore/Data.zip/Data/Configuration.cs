﻿namespace VaporStore.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=ASUS-PC\SQLEXPRESS;Database=VaporStore;Integrated Security=True;Encrypt=False";
    }
}