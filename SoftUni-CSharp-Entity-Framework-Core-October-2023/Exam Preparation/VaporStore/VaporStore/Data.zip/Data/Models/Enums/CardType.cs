﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VaporStore.Data.Models.Enums
{
    public enum CardType
    { 
        Debit = 0, 
        Credit = 1
    }
}
