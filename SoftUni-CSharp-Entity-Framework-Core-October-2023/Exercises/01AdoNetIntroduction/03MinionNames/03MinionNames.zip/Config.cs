﻿namespace _02VillianNames
{
    public static class Config
    {
        public const string ConnectionString = @"Server=INTEL\SQLEXPRESS;Database=MinionsDB;Integrated Security=True;";
    }
}
